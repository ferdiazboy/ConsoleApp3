# InterfaceAndAbstractDemo

YouTube Canlı yayını kodlarıdır.
https://www.youtube.com/watch?v=6VYDltTF2b4

Uygulamanın çalışması için Program.cs içinde kendi bilgilerinizi vermeniz gerekmektedir.

namespace InterfaceAndAbstractDemo.Abstract
{
    public interface IEntity
    {
    }
}